print('Hello, world!')
