s1 = input().strip()
s2 = input().strip()

if sorted(s1) == sorted(s2):
    print("YES")
else:
    print("NO")