a = int(input())
b = int(input())

if b == 0:
    print("Деление на ноль!")
    print("Деление на ноль!")
else:
    print(a // b)
    print(a / b)
