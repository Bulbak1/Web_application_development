s = input()
print('-'.join(s.split()))