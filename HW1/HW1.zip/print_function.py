n = int(input())

if 1 <= n <= 20:
   for i in range(1, n + 1):
    print(i, end='')
else:
    print("Неверное значение")
